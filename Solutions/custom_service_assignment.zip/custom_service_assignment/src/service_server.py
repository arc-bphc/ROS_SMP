#! /usr/bin/env python
import rospy
from custom_service_assignment.srv import CustomServiceMessage, CustomServiceMessageResponse
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist

# read from /scan and /odom to get the distance
response = CustomServiceMessageResponse() 
laserObject = LaserScan()
odom = Odometry()

def response_callback(request):
   
    distance_covered = 0.0
    collision_threshold = 0.5
    twist = Twist()

    #laserObject will get updated in the sub callback
    global laserObject 
    distance_from_obstacle = laserObject.ranges[0]
    staring_positon_x = odom.pose.pose.position.x
    distance_covered = 0.0

    while distance_from_obstacle> collision_threshold:
        # calculate the distance
        rospy.loginfo("Distance from obstacle: %f" %distance_from_obstacle)
        distance_covered = odom.pose.pose.position.x - staring_positon_x
        if distance_covered < request.distance:
            # move the bot forward
            twist.linear.x = 0.3
            vel_pub.publish(twist)
        
        else:
            # stop the bot and set the reponse variables
            twist.linear.x = 0
            vel_pub.publish(twist)
            rospy.loginfo("Success: Distance covered; Stopped the bot")
            response.success = True
            response.additional_message = "Bot successfully covered the distance: %f" %distance_covered
            return response
        
        distance_from_obstacle = laserObject.ranges[0]
    
    # obstacle in front of the bot
    twist.linear.x = 0
    vel_pub.publish(twist)
    rospy.loginfo("Failure: Obstacle in front of the bot")
    response.success = False
    response.additional_message = "Obstacle encountered! Total distance covered: %f" %distance_covered
    return response


    return response

def laser_callback(msg):
    # we get an object of LaserScan type
    global laserObject 
    laserObject = msg

def odom_callback(msg):
    global odom
    odom = msg

if __name__ == '__main__':
    rospy.init_node('custom_server_node')
    # create the Service called my_service with the defined callback

    # subscribe to the /scan and /odom
    scan_sub = rospy.Subscriber('/scan', LaserScan, laser_callback, queue_size=1 )
    odom_sub = rospy.Subscriber('/odom', Odometry, odom_callback, queue_size=1)

    # publisher for moving the bot
    vel_pub = rospy.Publisher('/cmd_vel', Twist, latch = True, queue_size=1)

    my_service = rospy.Service('/custom_service_assignment', CustomServiceMessage, response_callback)
    rospy.loginfo("Custom service is running!")
    rospy.spin() # maintain the service open.