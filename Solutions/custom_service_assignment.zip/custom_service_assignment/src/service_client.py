#! /usr/bin/env python
import rospy
from custom_service_assignment.srv import CustomServiceMessage, CustomServiceMessageRequest

rospy.init_node("simple_service_client")

#Wait for the service to be active
rospy.wait_for_service('/custom_service_assignment')
rospy.loginfo("Service is running!")

request = CustomServiceMessageRequest()
service_client = rospy.ServiceProxy('/custom_service_assignment', CustomServiceMessage)

request.distance = input(" Enter the distance to move the bot forward: ")
response = service_client(request)
while response.success:
    print(response.additional_message)
    request.distance = input(" Enter the distance to move the bot forward again: ")
    response = service_client(request)

# Obstacle encountered
print(response.additional_message)